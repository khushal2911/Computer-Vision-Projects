%{
Function Description: This function re-estimates the values of p and q by applying one iteration of the elliptic p.d.e.
Inputs: (1) p_ideal, q_ideal : for boundary contions
        (2) p , q : the previous values of p and q
        (3) Img : the image
        (4) ps,qs,ps_,qs_ : the two light source directions
        (5) alpha,beta : Relative strengths of the light sources
Outputs: pb and qb - the reestimated p and q matrices 
%}
function [a,b] = reestpq_2s(p_ideal,q_ideal,p,q,Img,ps,qs,ps_,qs_,r,alpha,beta) 
    pb = zeros(64);
    qb = zeros(64);
    for i = 2:63
        for j = 2:63
            lambda =   .5;
            P = p(i,j);
            Q = q(i,j);
            B1 = P^2+Q^2+1;
            B2 = ps^2+qs^2+1;
            B3 = P*ps+Q*qs+1;
            B4 = ps_^2+qs_^2+1;
            B5 = P*ps_+Q*qs_+1;
            p_avg = (p(i-1,j)+p(i,j-1)+p(i+1,j)+p(i,j+1)+p(i-1,j-1)+p(i+1,j-1)+p(i+1,j+1)+p(i-1,j+1))/8;
            q_avg = (q(i-1,j)+q(i,j-1)+q(i+1,j)+q(i,j+1)+q(i-1,j-1)+q(i+1,j-1)+q(i+1,j+1)+q(i-1,j+1))/8;
            E = Img(i,j);
            R = (ps*P + qs*Q +1)/(sqrt(ps*ps+qs*qs+1)*sqrt(P*P+Q*Q+1));
            Rp= (ps*B1^.5*B2^.5 - P*B1^(-.5)*B2^.5*B3)/(B1*B2); 
            Rq= (qs*B1^.5*B2^.5 - Q*B1^(-.5)*B2^.5*B3)/(B1*B2);
            R_ = (ps_*P + qs_*Q +1)/(sqrt(ps_*ps_+qs_*qs_+1)*sqrt(P*P+Q*Q+1));
            Rp_= (ps_*B1^.5*B4^.5 - P*B1^(-.5)*B4^.5*B5)/(B1*B4); 
            Rq_= (qs_*B1^.5*B4^.5 - Q*B1^(-.5)*B4^.5*B5)/(B1*B4);
            Rp_net = alpha*Rp + beta*Rp_;
            Rq_net = alpha*Rq + beta*Rq_;
            R_net = alpha*R + beta*R_;
            
            
            
            x = (i/64)*64 - 32;        
            y = (j/64)*64 - 32;
            if x^2 + y^2 < (r/2)^2+3 && x^2 + y^2 > (r/2)^2-3
                pb(i,j) = p_ideal(i,j);
                qb(i,j) = q_ideal(i,j);
            else
                pb(i,j) = p_avg + ((E-R_net)*Rp_net)/lambda;
                qb(i,j) = q_avg + ((E-R_net)*Rq_net)/lambda;
            end                        
        end
    end
    a = pb;
    b = qb;    
end
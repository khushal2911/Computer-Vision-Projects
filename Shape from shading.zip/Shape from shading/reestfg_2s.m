%{
Function Description: This function re-estimates the values of f and g by applying one iteration of the elliptic p.d.e.
Inputs: (1) f_ideal, g_ideal : for boundary contions
        (2) f , g : the previous values of f and g
        (3) Img : the image
        (4) ps,qs,ps_,qs_ : the two light source directions
        (5) alpha,beta : Relative strengths of the light sources
Outputs: fb and gb - the reestimated f and g matrices 
%}
function [a,b] = reestfg_2s(f_ideal,g_ideal,f,g,Img,ps,qs,ps_,qs_,r,alpha,beta) 
    fb = zeros(64);
    gb = zeros(64);
    for i = 2:63
        for j = 2:63            
            lambda =   .8;
            
            P = 4*f(i,j)/(4-f(i,j)^2-g(i,j)^2) ;
            Q = 4*g(i,j)/(4-f(i,j)^2-g(i,j)^2) ;
            B1 = P^2+Q^2+1;
            B2 = ps^2+qs^2+1;
            B3 = P*ps+Q*qs+1;
            B4 = ps_^2+qs_^2+1;
            B5 = P*ps_+Q*qs_+1;
            
            f_avg = (f(i-1,j)+f(i,j-1)+f(i+1,j)+f(i,j+1)+f(i-1,j-1)+f(i+1,j-1)+f(i+1,j+1)+f(i-1,j+1))/8;
            g_avg = (g(i-1,j)+g(i,j-1)+g(i+1,j)+g(i,j+1)+g(i-1,j-1)+g(i+1,j-1)+g(i+1,j+1)+g(i-1,j+1))/8;
            E = Img(i,j);
            
            R = (ps*P + qs*Q +1)/(sqrt(ps*ps+qs*qs+1)*sqrt(P*P+Q*Q+1));
            Rp= (ps*B1^.5*B2^.5 - P*B1^(-.5)*B2^.5*B3)/(B1*B2); 
            Rq= (qs*B1^.5*B2^.5 - Q*B1^(-.5)*B2^.5*B3)/(B1*B2);
            
            R_ = (ps_*P + qs_*Q +1)/(sqrt(ps_*ps_+qs_*qs_+1)*sqrt(P*P+Q*Q+1));
            Rp_= (ps_*B1^.5*B4^.5 - P*B1^(-.5)*B4^.5*B5)/(B1*B4); 
            Rq_= (qs_*B1^.5*B4^.5 - Q*B1^(-.5)*B4^.5*B5)/(B1*B4);
            
            
            
            Pf = (4*(4-f(i,j)^2-g(i,j)^2)+8*f(i,j)^2)/(4-f(i,j)^2-g(i,j)^2)^2; 
            Pg = (8*f(i,j)*g(i,j))/(4-f(i,j)^2-g(i,j)^2)^2;
            Qf = (8*f(i,j)*g(i,j))/(4-f(i,j)^2-g(i,j)^2)^2;
            Qg = (4*(4-f(i,j)^2-g(i,j)^2)+8*g(i,j)^2)/(4-f(i,j)^2-g(i,j)^2)^2;
            
            Rf = Rp*Pf + Rq*Qf;
            Rg = Rp*Pg + Rq*Qg;
            Rf_ = Rp_*Pf + Rq_*Qf;
            Rg_ = Rp_*Pg + Rq_*Qg; 
            
            Rf_net = alpha*Rf + beta*Rf_;
            Rg_net = alpha*Rg + beta*Rg_;
            R_net = alpha*R + beta*R_;
            
            
            x = (i/64)*64 - 32;        
            y = (j/64)*64 - 32;
            if x^2 + y^2 < (r/2)^2+3 && x^2 + y^2 > (r/2)^2-3
                fb(i,j) = f_ideal(i,j);
                gb(i,j) = g_ideal(i,j);
            else
                fb(i,j) = f_avg + ((E-R_net)*Rf_net)/lambda;
                gb(i,j) = g_avg + ((E-R_net)*Rg_net)/lambda;
            end                        
        end
    end
    a = fb;
    b = gb;    
end






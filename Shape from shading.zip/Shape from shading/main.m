%% Setting up the simulation environment:

Img = zeros(64);
z_ideal = zeros(64);
p_ideal = zeros(64);
q_ideal = zeros(64);
f_ideal = zeros(64);
g_ideal = zeros(64);

% Surface parameters: 
r = 20;     
z0 = 32;


% Source directions and relative strengths:
ps = 0;
qs = 0;
ps_ = -0.5;
qs_ = -0.5;
alpha = 1;
beta = 0;

% Generating z,p,q,f,g and E ie. the image:
for i = 1:64
    for j = 1:64        
        x = (i/64)*64 - 32;        
        y = (j/64)*64 - 32;        
        if r*r - x*x - y*y >= 0 
            z_ideal(i,j) = z0 - sqrt(r*r - x*x - y*y);
            p_ideal(i,j) = (1/(z0-z_ideal(i,j)))*x;
            q_ideal(i,j) = (1/(z0-z_ideal(i,j)))*y;
            f_ideal(i,j) = 2*x/(1+z0-z_ideal(i,j)); 
            g_ideal(i,j) = 2*y/(1+z0-z_ideal(i,j));
            Img(i,j) = alpha*((ps*p_ideal(i,j) + qs*q_ideal(i,j) +1)/(sqrt(ps*ps+qs*qs+1)*sqrt(p_ideal(i,j)*p_ideal(i,j)+q_ideal(i,j)*q_ideal(i,j)+1))) + beta*((ps_*p_ideal(i,j) + qs_*q_ideal(i,j) +1)/(sqrt(ps_*ps_+qs_*qs_+1)*sqrt(p_ideal(i,j)*p_ideal(i,j)+q_ideal(i,j)*q_ideal(i,j)+1)));
        else
            z_ideal(i,j) = z0;
            p_ideal(i,j)=0;
            q_ideal(i,j)=0;
            f_ideal(i,j)=0;
            g_ideal(i,j)=0;
            Img(i,j) = 0;
        end        
        Img(i,j) = max(0,Img(i,j));
    end
end



%Noisy Image:
n = wgn(64,64,-1);
Img_noisy = Img + n;








%% Recovery of shape from shading


%Initialize p and q with boundary conditions
pb = zeros(64);
qb = zeros(64);
p = zeros(64);
q = zeros(64);
for i = 1:64
    for j = 1:64        
        x = (i/64)*64 - 32;        
        y = (j/64)*64 - 32;
        if x^2 + y^2 < (r/2)^2+3 && x^2 + y^2 > (r/2)^2-3
            p(i,j) = p_ideal(i,j);
            q(i,j) = q_ideal(i,j);
        end    
        
    end
end
%Iteratively call reestpq_2s() to estimate p and q
for n = 1:1000
    [pb,qb] = reestpq_2s(p_ideal,q_ideal,p,q,Img,ps,qs,ps_,qs_,r,alpha,beta);
    p = pb;
    q = qb;
end




%Initialize f and g with boundary conditions
fb = zeros(64);
gb = zeros(64);
f = zeros(64);
g = zeros(64);
for i = 1:64
    for j = 1:64        
        x = (i/64)*64 - 32;        
        y = (j/64)*64 - 32;
        if x^2 + y^2 < (r/2)^2+3 && x^2 + y^2 > (r/2)^2-3
            f(i,j) = f_ideal(i,j);
            g(i,j) = g_ideal(i,j);
        end    
        
    end
end
%Iteratively call reestfg_2s() to estimate f and g
for n = 1:1000
    [fb,gb] = reestfg_2s(f_ideal,g_ideal,f,g,Img,ps,qs,ps_,qs_,r,alpha,beta);
    f = fb;
    g = gb;
end







%Estimate z from p and q using reestz()
z_pq = zeros(64);
for n = 1:10000
    zb = reestz_pq(z_pq,p,q,r,z_ideal);
    z_pq = zb;
end




%Estimate z from f and g using reestz_fg()
z_fg = zeros(64); 
for n = 1:10000
    zb = reestz_fg(z_fg,f,g,r,z_ideal);
    z_fg = zb;
end











%Image reconstructed from estimated p and q
Img_rec = zeros(64);
for i = 1:64
    for j = 1:64        
        x = (i/64)*64 - 32;        
        y = (j/64)*64 - 32;        
        if r*r - x*x - y*y >= 0 
            Img_rec(i,j) = alpha*((ps*p(i,j) + qs*q(i,j) +1)/(sqrt(ps*ps+qs*qs+1)*sqrt(p(i,j)*p(i,j)+q(i,j)*q(i,j)+1))) + beta*((ps_*p(i,j) + qs_*q(i,j) +1)/(sqrt(ps_*ps_+qs_*qs_+1)*sqrt(p(i,j)*p(i,j)+q(i,j)*q(i,j)+1)));
        else

            Img_rec(i,j) = 0;
        end        
        Img_rec(i,j) = max(0,Img_rec(i,j));
    end
end



 
figure('name','image of ground truth')
imshow(Img);

figure('name','image reconstructed from estimated p and q')
imshow(Img_rec);

figure('name','Ground truth')
surf((32*ones(64)-z_ideal));
axis equal;

figure('name','Shape estimated using p and q')
surf(z_pq);
axis equal;

figure('name','Shape estimated using f and g')
surf(z_fg);
axis equal;







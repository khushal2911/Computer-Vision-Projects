%{
Function description: This function estimates the shape z of the object
from the estimated values of p and q
Inputs: (1) z : the previous value of z 
        (2)p,q: to be used in the differential equation for estimating z
        (3)z_ideal: for boundary conditions
Outputs: Re-estimated values of shape zb
%}
function [a] = reestz_pq(z,p,q,r,z_ideal) 
    zb = zeros(64);
    [px,py] = gradient(p);
    [qx,qy] = gradient(q);
    for i = 2:63
        for j = 2:63
            x = i - 32;        
            y = j - 32;
            z_avg = (z(i-1,j)+z(i,j-1)+z(i+1,j)+z(i,j+1)+z(i-1,j-1)+z(i+1,j-1)+z(i+1,j+1)+z(i-1,j+1))/8;            
            if  x^2 + y^2 > r^2
                zb(i,j) = 0;
            else
                zb(i,j) = z_avg + (py(i,j) + qx(i,j))/2;
            end
                        
        end
    end
    a = zb;    
end
function disp_map = update_disp_L(A,edges,ILgray,IRgray)
    s = size(A);
    disp_map = zeros(s);
    lambda = .5 ;   
    for i = 2:s(1)-1
        for j = 2:s(2)-1
            flx = ILgray(i,j+1)-ILgray(i,j);
            dav = (A(i-1,j)+ A(i+1,j) + A(i,j+1) + A(i,j-1))/4 ;
            if edges(i,j) ~= 0
                disp_map(i,j) = A(i,j);
            else
                disp_map(i,j) = dav - lambda*(ILgray(i,j) - IRgray(i,j) - A(i,j)*flx)*flx;
            end
        end
    end
end
clc
clear all
s1 = 'D:\Dropbox\acads\sem 8\EE 702Computer Vision\project2\middlebury\ALL-2views\Baby1\view1.png';
s2 = 'D:\Dropbox\acads\sem 8\EE 702Computer Vision\project2\middlebury\ALL-2views\Baby1\view5.png';
IL = imread(s1);
ILgray = rgb2gray(IL);
IR = imread(s2);
IRgray = rgb2gray(IR);
[nrows, ncols] = size(ILgray);

% Convert the left and right images from uint8 to double
ILgray  = im2double(ILgray);
IRgray = im2double(IRgray);

ILedges = edge(ILgray,'sobel',0.01);
IRedges = edge(IRgray,'sobel',0.01);
ILedges = +ILedges;
IRedges = +IRedges;

%  figure;
%  imshow(ILedges);
%  figure;
%  imshow(IRedges);

windowsize = 21;
a = (windowsize-1)/2;
disp_map = zeros(nrows,ncols);
bc = zeros(nrows,ncols);
for i = a+1:nrows-a
    for j = a+1:ncols-a-60
    disp_buffer = zeros(1,60);
    v1 = IRedges(i-a:i+a,j-a:j+a);
    for k = 1:60
        v2 = ILedges(i-a:i+a,j+k-a:j+k+a);
        x= v2.*v1;
        disp_buffer(k) = sum(sum(x));
    end
    [m,argm] = max(disp_buffer);
    if IRedges(i,j) ~= 0 %&& m > 18
        disp_map(i,j)= argm;
    end    
    end
end
figure(1)
imshow(mat2gray(disp_map));


for i = 1:500
   disp_map = update_disp(disp_map,IRedges,ILgray,IRgray); 
end

figure(2)
imshow(mat2gray(disp_map));


disp_map_L = zeros(nrows,ncols);
bc_L = zeros(nrows,ncols);
for i = a+1:nrows-a
    for j = a+1+60:ncols-a
    disp_buffer = zeros(1,60);
    v1 = ILedges(i-a:i+a,j-a:j+a);
    for k = 1:60
        v2 = IRedges(i-a:i+a,j-k-a:j-k+a);
        x= v2.*v1;
        disp_buffer(k) = sum(sum(x));
    end
    [m,argm] = max(disp_buffer);
    if ILedges(i,j) ~= 0 %&& m > 18
        disp_map_L(i,j)= argm;
    end    
    end
end

figure(3)
imshow(mat2gray(disp_map_L));


for i = 1:500
   disp_map_L = update_disp_L(disp_map_L,ILedges,ILgray,IRgray); 
end

figure(4)
imshow(mat2gray(disp_map_L));

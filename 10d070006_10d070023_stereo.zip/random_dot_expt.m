RD1 = rand(370,220,'double');
RD2 = RD1;
figure(1)
imshow(RD1)

square = zeros(100);
for i = 1:100
    for j =1:100
        square(i,j) = RD1(100+i,100+j);
    end
end
figure(2)
imshow(square)

for k = 1:100
    for l=1:100        
        RD2(100+k,50+l) = square(k,l);
    end
end
figure(3)
imshow(RD2)

ILgray = RD1;
IRgray = RD2;
[nrows, ncols] = size(ILgray);

ILedges = edge(ILgray,'sobel',0.01);
IRedges = edge(IRgray,'sobel',0.01);
ILedges = +ILedges;
IRedges = +IRedges;

windowsize = 21;
a = (windowsize-1)/2;
disp_map = zeros(nrows,ncols);
bc = zeros(nrows,ncols);
for i = a+1:nrows-a
    for j = a+1:ncols-a-50
    disp_buffer = zeros(1,50);
    v1 = IRedges(i-a:i+a,j-a:j+a);
    for k = 1:50
        v2 = ILedges(i-a:i+a,j+k-a:j+k+a);
        x= v2.*v1;
        disp_buffer(k) = sum(sum(x));
    end
    [m,argm] = max(disp_buffer);
    if IRedges(i,j) ~= 0 %&& m > 18
        disp_map(i,j)= argm;
    end    
    end
end
figure(4)
imshow(mat2gray(disp_map));

% 
% disp_map_L = zeros(nrows,ncols);
% bc_L = zeros(nrows,ncols);
% for i = a+1:nrows-a
%     for j = a+1+50:ncols-a
%     disp_buffer = zeros(1,50);
%     v1 = ILedges(i-a:i+a,j-a:j+a);
%     for k = 1:50
%         v2 = IRedges(i-a:i+a,j-k-a:j-k+a);
%         x= v2.*v1;
%         disp_buffer(k) = sum(sum(x));
%     end
%     [m,argm] = max(disp_buffer);
%     if ILedges(i,j) ~= 0 %&& m > 18
%         disp_map_L(i,j)= argm;
%     end    
%     end
% end
% 
% figure(3)
% imshow(mat2gray(disp_map_L));


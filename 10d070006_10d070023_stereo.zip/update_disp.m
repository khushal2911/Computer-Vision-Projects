function disp_map = update_disp(A,edges,ILgray,IRgray)
    s = size(A);
    disp_map = zeros(s);
    lambda = .5 ;   
    for i = 2:s(1)-1
        for j = 2:s(2)-1
            frx = IRgray(i,j+1)-IRgray(i,j);
            dav = (A(i-1,j)+ A(i+1,j) + A(i,j+1) + A(i,j-1))/4 ;
            if edges(i,j) ~= 0
                disp_map(i,j) = A(i,j);
            else
                disp_map(i,j) = dav + lambda*(IRgray(i,j) - ILgray(i,j) + A(i,j)*frx)*frx;
            end
        end
    end
end